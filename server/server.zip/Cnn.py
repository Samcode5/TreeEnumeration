import numpy as np
import tensorflow as tf
from glob import glob
import os
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
import seaborn as sns
import cv2
from tensorflow.keras.models import load_model
import joblib
import math

IMG_SIZE = (256,256)
img_path="D:\\Projects\\Tree_Enumeration\\server\\img.png"
img = tf.io.read_file(img_path)
img = tf.io.decode_jpeg(img)
img = tf.image.convert_image_dtype(img, tf.float32)
img = tf.image.resize(img, IMG_SIZE)
img = img[:, :, :3]
img = tf.expand_dims(img, axis=0)

cnn_model_path="D:\\Projects\\Tree_Enumeration\\server\\tree_detection_model.h5"
saved_model = load_model(cnn_model_path)
# Make predictions using the loaded model
# pred = saved_model.predict(tf.expand_dims(img, axis=0))
pred=saved_model.predict(img)
# Load the saved linear regression model
linear_model_path="D:\\Projects\\Tree_Enumeration\\server\\linear_regression_model.pkl"
loaded_lin_reg_model = joblib.load(linear_model_path)
total_dens_pred = tf.reduce_sum(pred, axis=[1,2,3]).numpy()
print(total_dens_pred*loaded_lin_reg_model)
# print(math.floor(result))